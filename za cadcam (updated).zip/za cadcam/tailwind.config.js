/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    extend: {},
  },
  plugins: [],
}
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
// module.exports = {
//   theme: {
//     extend: 
//       colors: {
//         primary: '#003366', // Dark Blue/Navy
//         secondary: '#FFD700', // Gold/Tan
//         background: '#F5F5F5', // Light Grey
//         text: '#333333', // Dark Grey
//         hover: '#004080', // Light Blue or Darker Shade
//       },
//     },
//   },
// };

